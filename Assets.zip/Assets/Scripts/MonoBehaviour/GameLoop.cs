using System.Linq;
using UnityEngine;
using TMPro;
using System.Collections.Generic;
using System;
using UnityEngine.UI;
using System.Collections;

public class GameLoop : MonoBehaviour
{
	[SerializeField] private Transform _board;

	private GameUI _controls;

	private short _activePlayerIndex { get; set; }
	private const short c_cardMaxAmount = 6;

	public Game Game { get; private set; }
	public Dictionary<Player, short> Bids { get; private set; }
	public Player ActivePlayer { get => Game.Players[_activePlayerIndex]; }
	public bool IsControlsEnabled { get; set; }

    private void Awake()
    {
		Game = GamePreloader.Instance.Game;
		_controls = GetComponent<GameUI>();
		_activePlayerIndex = 0;
		Bids = new Dictionary<Player, short>();
		_controls.Lands = MapLoader.DrawMap(Game.GameMap, _board);

		var landObjs = _controls.Lands.Cast<Transform>().ToArray();
		var lands = Game.GameMap.Lands;

		if(landObjs.Length == lands.Length)
		{
			for (var i = 0; i < landObjs.Length; i++)
				lands[i].LandObj = landObjs[i].GetComponent<Image>();
		}
    }

	private void Start()
	{
		PreparePlayers();
		_controls.DrawPlayers(Game.Players);
		_controls.DrawCards(GenerateCards());
		ToggleControls(false);
		InitiateBidding();
	}

	private void Update()
	{
		if(Input.GetMouseButtonDown(0) && IsControlsEnabled)
		{
			var worldPoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			var hit = Physics2D.Raycast(worldPoint, Vector3.forward);
			var clickedNode = Game.GameMap.Graph.Nodes.FirstOrDefault(n => n.Value.Name.Equals(hit.collider.name));

			clickedNode.Value.LandObj.color = new Color(0, 1, 0);
			StartCoroutine(LandClick(clickedNode.Value)); //  Will be replaced later
		}
	}

	private IEnumerator LandClick(Land land)
	{
		// Placeholder method (will be removed)

		land.LandObj.color = new Color(0, 1, 0);
		yield return new WaitForSeconds(2);
		land.LandObj.color = new Color(1, 1, 1);
	}

	public void ToggleControls(bool state)
	{
		IsControlsEnabled = state;
		_controls.Cover(!state);
	}

	private Card[] GenerateCards()
	{
		var cardGenerator = new System.Random();
		var cardSet = new Card[c_cardMaxAmount];

		for (var i = 0; i < c_cardMaxAmount; i++)
		{
			cardSet[i] = GenerateCard(cardGenerator, i switch
			{
				0 => 0,
				1 => 1,
				2 => 1,
				3 => 2,
				4 => 2,
				5 => 3
			});
		}

		return cardSet;
	}

	private Card GenerateCard(System.Random cardGenerator, short cardPrice)
	{
		var cardResource = (Resource)cardGenerator.Next(0, 5);
		var actionCount = cardGenerator.Next(1, 3);
		var cardActions = new Card.CardAction[actionCount];

		for (var i = 0; i < actionCount; i++)
			cardActions[i] = Card.ActionArray[cardGenerator.Next(Card.ActionArray.Length)];

		var card = new Card(cardResource, cardActions);

		card.Price = cardPrice;
		return card;
	}

	private void InitiateBidding()
	{
		foreach (var player in Game.Players.Where(p => p is ComputerPlayer))
			Bids.Add(player, 4);

		_controls.StartBidding();
	}

	public Player NextPlayer()
	{
		try
		{
			return Game.Players[++_activePlayerIndex];
		}
		catch(IndexOutOfRangeException ex)
		{
			return null;
		}
	}

	private void PreparePlayers()
	{
		foreach(var player in Game.Players)
		{
			player.Armies = 14;
			player.Cities = 3;
			player.Coins = Game.PlayerCount switch
			{
				5 => 8,
				4 => 9,
				3 => 11,
				2 => 14
			};
		}
	}
}
