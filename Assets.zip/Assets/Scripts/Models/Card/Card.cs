using System;

public class Card
{
	public Resource Resource { get; private set; }
	public CardAction[] Actions { get; private set; }
	public short Price { get; set; }
	public Player Owner { get; set; }

	public Card(Resource resource, CardAction[] actions)
	{
		Resource = resource;
		Actions = actions;
		Price = 0;
	}

	public static CardAction[] ActionArray = new CardAction[]
	{
		Recruit,
		MoveInland,
		MoveOversea,
		BuildCity,
		Battle
	};

	public delegate void CardAction(Land source, Player sourcePlayer, Land destination, Player targetPlayer);

	public static void Recruit(Land destination, Player sourcePlayer, Land source = null, Player targetPlayer = null)
	{
		sourcePlayer.Armies--;
		destination.ArmiesPresence[sourcePlayer]++;
	}

	public static void MoveInland(Land source, Player sourcePlayer, Land destination, Player targetPlayer = null)
	{
		source.ArmiesPresence[sourcePlayer]--;
		destination.ArmiesPresence[sourcePlayer]++;
	}

	public static void MoveOversea(Land source, Player sourcePlayer, Land destination, Player targetPlayer = null)
	{
		source.ArmiesPresence[sourcePlayer]--;
		destination.ArmiesPresence[sourcePlayer]++;
	}

	public static void BuildCity(Land destination, Player sourcePlayer, Land source = null, Player targetPlayer = null)
	{
		destination.HasCity = sourcePlayer;
	}

	public static void Battle(Land source, Player sourcePlayer, Land destination = null, Player targetPlayer = null)
	{
		source.ArmiesPresence[targetPlayer]--;
	}
}