public enum Resource
{
	TIMBER,
	FOOD,
	STONE,
	METAL,
	GEMSTONES
}