using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.Events;
using System;
using System.Threading.Tasks;

public class GameUI : MonoBehaviour
{
	[SerializeField] private RectTransform _biddingScreen;
	[SerializeField] private Image _imgBiddingColor;
	[SerializeField] private TMP_Text _txtBiddingPlayer;
	[SerializeField] private TMP_InputField _inBiddingAmount;
	[SerializeField] private Button _btnBiddingConfirm;

	[SerializeField] private Sprite[] _spriteAction;
	[SerializeField] private Sprite[] _spriteResource;

	[SerializeField] private RectTransform _cardPanel;
	[SerializeField] private RectTransform _cardHolder;

	[SerializeField] private RectTransform _playerPanel;
	[SerializeField] private RectTransform _playerHolder;

	[SerializeField] private GameObject _cover;

	private GameLoop _gameLoop;

	private delegate void LoadData<T>(T data, RectTransform obj);

	public Transform Lands;

	private void Awake()
	{
		_gameLoop = GetComponent<GameLoop>();
		_btnBiddingConfirm.onClick.AddListener(CallbackBiddingConfirm);
	}

	private void ShowBiddingScreen(Player player)
	{
		// Lock other UI

		if (player is ComputerPlayer)
			ShowBiddingScreen(_gameLoop.NextPlayer());
		else
		{
			_biddingScreen.gameObject.SetActive(true);
			_txtBiddingPlayer.text = player.Name;
			_imgBiddingColor.color = player.Color;
			_inBiddingAmount.text = "";
		}
	}

	private void DrawArray<T>(T[] objects, float startingHeight, float heightDifference, RectTransform prefab, RectTransform panel, LoadData<T> loadData)
	{
		for(var i = 0; i < objects.Length; i++)
		{
			var obj = instantiateObject(i);
			loadData(objects[i], obj);
		}

		RectTransform instantiateObject(int index)
		{
			var obj = Instantiate(prefab, panel);

			obj.anchoredPosition = new Vector2(0, startingHeight - index * heightDifference);
			return obj;
		}
	}

	private void LoadCardGraphics(Card card, RectTransform cardObj)
	{
		var price = cardObj.GetChild(0).GetChild(0).GetComponent<TMP_Text>();
		var resourceIcon = cardObj.GetChild(1).GetChild(0).GetComponent<Image>();
		var actionIcon = cardObj.GetChild(1).GetChild(1).GetComponent<Image>();

		price.text = card.Price.ToString();
		resourceIcon.sprite = _spriteResource[(int)card.Resource];

		if (card.Actions[0] == Card.Battle)
			actionIcon.sprite = _spriteAction[0];
		else if (card.Actions[0] == Card.BuildCity)
			actionIcon.sprite = _spriteAction[1];
		else if (card.Actions[0] == Card.Recruit)
			actionIcon.sprite = _spriteAction[2];
		else if (card.Actions[0] == Card.MoveOversea)
			actionIcon.sprite = _spriteAction[3];
		else if (card.Actions[0] == Card.MoveInland)
			actionIcon.sprite = _spriteAction[4];
	}

	private void LoadPlayerStats(Player player, RectTransform playerObj)
	{
		var scoreBg = playerObj.GetChild(0).GetComponent<Image>();
		var score = playerObj.GetChild(0).GetChild(0).GetComponent<TMP_Text>();
		var name = playerObj.GetChild(1).GetComponent<TMP_Text>();
		var cities = playerObj.GetChild(2).GetChild(1).GetComponent<TMP_Text>();
		var armies = playerObj.GetChild(2).GetChild(3).GetComponent<TMP_Text>();
		var coins = playerObj.GetChild(2).GetChild(5).GetComponent<TMP_Text>();

		scoreBg.color = player.Color;
		score.text = player.Score.ToString();
		name.text = player.Name;
		cities.text = player.Cities.ToString();
		armies.text = player.Armies.ToString();
		coins.text = player.Coins.ToString();
	}

	private void HideBiddingScreen()
	{
		_biddingScreen.gameObject.SetActive(false);
	}

	public void Cover(bool state)
	{
		_cover.SetActive(state);
	}

	public void DrawPlayers(Player[] players)
	{
		DrawArray<Player>(players, 0f, 92f, _playerHolder, _playerPanel, LoadPlayerStats);
	}


	public void DrawCards(Card[] cards)
	{
		DrawArray<Card>(cards, 400.42f, 160.17f, _cardHolder, _cardPanel, LoadCardGraphics);
	}

	public void StartBidding()
	{
		ShowBiddingScreen(_gameLoop.ActivePlayer);
	}

	public void CallbackBiddingConfirm()
	{
		try
		{
			var bid = short.Parse(_inBiddingAmount.text);

			if(bid > _gameLoop.ActivePlayer.Coins)
			{
				CallbackBiddingConfirm();
				return;
			}

			_gameLoop.Bids.Add(_gameLoop.ActivePlayer, short.Parse(_inBiddingAmount.text));

			var nextPlayer = _gameLoop.NextPlayer();

			if (nextPlayer is null)
			{
				HideBiddingScreen();
				_gameLoop.IsControlsEnabled = true;
				Cover(false);
			}
				
			else
				ShowBiddingScreen(nextPlayer);
		}
		catch(FormatException ex)
		{
			// TODO Show error screen
			print(ex.Message);
		}
	}
}